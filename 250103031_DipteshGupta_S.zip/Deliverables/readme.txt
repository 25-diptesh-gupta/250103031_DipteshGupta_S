The MATLAB script allows you to change the image you want to filter

Ioriginal = imread("imagesCorrupt/cursed_schematic_02.png") ; 

reads the second schematic from the 'imagesCorrupt' folder. 
Simply change the number '02' to any other number (from 01 to 05) to change the image being processed. 