clc , clearvars , close all   
%% READ IMAGE

Ioriginal = imread("imagesCorrupt/cursed_schematic_02.png") ; 
%% SPATIAL FILTERING

Ispatialfilt = medfilt2(Ioriginal,[3 3]) ; 
%% FOURIER TRANSFORM

Ifourier = fftshift(fft2(Ispatialfilt)) ; 
Fmagnitude = log(1+abs(Ifourier)) ; 
%% FREQUENCY MASK CREATION

% We explicitly set the central low frequency core to 0
% To exclude it from the peak detection algorithm
FmagnitudeReference = zeros(256,256) ;
for i = 1:256
    for j = 1:256
        if(abs(i-128)<=15 && abs(j-128)<=15)
            FmagnitudeReference(i,j) = 0 ; 
        else
            FmagnitudeReference(i,j) = Fmagnitude(i,j) ;
        end
    end
end

% Find the bright spots in frequency spectrum
[pks,locs_X,locs_Y] = peaks2(FmagnitudeReference,'MinPeakHeight',12,'MinPeakDistance',5); ; 

%create frequency mask
mask = ones(256,256) ;
for i = 1:256 
    for j = 1:256 
       for k = 1:length(locs_X) 
           if(abs(i-locs_Y(k))<=2 && abs(j-locs_X(k))<=2)
               mask(i,j) = 0;
           end
       end
    end
end
%% APPLYING THE MASK

Ifourierfilter = Ifourier.*mask ;
Fmagnitudefilt = log(1+abs(Ifourierfilter)) ;
%% INVERSE FOURIER TRANSFORM AND FINAL FILTERING

Ifiltered = ifft2(ifftshift(Ifourierfilter)); 
Ifiltered = uint8(real(Ifiltered)); 

% The filtered image now shows a good contrast between the foreground and
% the background
% Creating a binary image further helps in making it clearer
Ibinary = imbinarize(Ifiltered) ; 
%% PLOTS

subplot(2,3,1) ; 
imshow(Ioriginal); 
title('Original Image');
subplot(2,3,2); 
imshow(Ispatialfilt); 
title('Spatially Filtered Image');
subplot(2,3,3); 
imshow(Fmagnitude, []); 
title('Frequency magnitude spectrum');
subplot(2,3,4);
imshow(mask) ;
title('Filtering mask') ;
subplot(2,3,5); 
imshow(Fmagnitudefilt, []);
title('Filtered frequency spectrum') ; 
subplot(2,3,6);
imshow(Ibinary);
title('Filtered image');